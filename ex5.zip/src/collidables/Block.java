package collidables;
import game.Ball;
import game.GameLevel;
import sprites.Sprite;
import hitlisteners.HitNotifier;
import hitlisteners.HitListener;
import geometry.Rectangle;
import geometry.Point;
import geometry.Velocity;
import biuoop.DrawSurface;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * Defining a Block class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class Block implements Collidable, Sprite, HitNotifier {

    /**
     * rect: The shape of the Block.
     */
    private Rectangle rect;
    /**
     * color: The color of the Block.
     */
    private Color color;
    /**
     * numOfHits: The amount of time the Block should be hit before it disappears.
     */
    private int numOfHits;

    /**
     * hitlisteners: A list of hitlisteners that will get notified when a hit event occurs.
     */
    private List<HitListener> hitListeners;

    /**
     * The Block's constructor.
     * @param point The Block's closest Point to the start of the screen.
     * @param width The Block's width.
     * @param height The Block's height.
     * @param blockColor The Block's color.
     * @param numHits The Block's number of hits.
     */
    public Block(final Point point, final int width, final int height, final Color blockColor, final int numHits) {
        this.rect = new Rectangle(point, width, height);
        this.color = blockColor;
        this.numOfHits = numHits;
        this.hitListeners = new ArrayList<>();
    }

    /**
     * The method sets the Ball's color.
     * @param blockColor The Block's color.
     */
    public final void setColor(final Color blockColor) { this.color = blockColor; }

    /**
     * The method adds the Block to the game.
     * @param game The game object which is passed, so the Block can add itself to the relevant members in game.
     */
    public final void addToGame(final GameLevel game) {
        game.addCollidable(this);
        game.addSprite(this);
        this.addHitListener(game);
    }

    /**
     * The method removes the Block from the game.
     * @param game The game object which is passed, so the Block can remove itself from the relevant members in game.
     */
    public final void removeFromGame(final GameLevel game) {
        game.removeCollidable(this);
        game.removeSprite(this);
        this.removeHitListener(game);
    }

    @Override
    public final Rectangle getCollisionRectangle() { return this.rect; }

    @Override
    public final Velocity hit(final Ball ball, final Point collisionPoint, final Velocity currentVelocity) {
        if (this.numOfHits > 0) { numOfHits--; }
        if (collisionPoint.getX() == this.rect.lowX() || collisionPoint.getX() == this.rect.topX()) {
            currentVelocity.horizontalChange();
        }
        if (collisionPoint.getY() == this.rect.lowY() || collisionPoint.getY() == this.rect.topY()) {
            currentVelocity.verticalChange();
        }
        this.notifyHit(ball);
        return currentVelocity;
    }

    /**
     * The method draws the Block on a given Drawsurface.
     * @param d The given drawSurface which the Block will be drawn on.
     */
    @Override
    public final void drawOn(final DrawSurface d) {
        d.setColor(this.color);
        d.fillRectangle(this.rect.lowX(), this.rect.lowY(), this.rect.getWidth(), this.rect.getHeight());
        d.setColor(Color.BLACK);
        d.drawLine(this.rect.lowX(), this.rect.lowY(), this.rect.lowX(), this.rect.topY());
        d.drawLine(this.rect.topX(), this.rect.lowY(), this.rect.topX(), this.rect.topY());
        d.drawLine(this.rect.lowX(), this.rect.lowY(), this.rect.topX(), this.rect.lowY());
        d.drawLine(this.rect.lowX(), this.rect.topY(), this.rect.topX(), this.rect.topY());
    }
    /**
     * The method notifies the Block that tie has passed.
     */
    @Override
    public final void timePassed() { }

    /**
     * The method returns true if the numOfHits is zero, else will return false.
     * @return True if the numOfHits is zero, else will return false.
     */
    public final boolean zeroHits() { return this.numOfHits == 0; }

    @Override
    public final void addHitListener(final HitListener hl) { this.hitListeners.add(hl); }

    @Override
    public final void removeHitListener(final HitListener hl) { this.hitListeners.remove(hl); }

    /**
     * The method notifies the hit listeners when a hit event occurs.
     * @param hitter The ball which a hit event would occur with.
     */
    private void notifyHit(final Ball hitter) {
        List<HitListener> listeners = new ArrayList<>(this.hitListeners);
        for (HitListener hl : listeners) { hl.hitEvent(this, hitter); }
    }
}
