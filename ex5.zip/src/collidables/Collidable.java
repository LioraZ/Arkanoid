package collidables;
import game.Ball;
import geometry.Velocity;
import geometry.Point;
import geometry.Rectangle;
/**
 * Defining a Collidable Interface.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public interface Collidable {

    /**
     * The method is an accessor to the collision rectangle.
     * @return The collision rectangle.
     */
    Rectangle getCollisionRectangle();

    /**
     * The method returns a new Velocity(movement angles) for the ball that hit this Block, and notifies the Block
     * that it was hit.
     * @param collisionPoint The collision point between the Ball and the Block.
     * @param currentVelocity The Ball's current Velocity.
     * @param ball The collision ball.
     * @return The Ball's new Velocity.
     */
    Velocity hit(Ball ball, Point collisionPoint, Velocity currentVelocity);
}
