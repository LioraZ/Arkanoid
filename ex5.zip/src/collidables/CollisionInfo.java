package collidables;
import geometry.Point;
import geometry.Velocity;
/**
 * Defining a CollisionInfo class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class CollisionInfo {

    /**
     * c: The colliding object.
     */
    private Collidable c;
    /**
     * collisionPoint: The collision point.
     */
    private Point collisionPoint;
    /**
     * list: A list to hold other collidables which have the same collision point.
     */
    private java.util.List<Collidable> list;

    /**
     * The Block's constructor.
     * @param cObject The colliding object.
     * @param cPoint The collision point.
     * @param other The list holding other collidables with the same collision point.
     */
    public CollisionInfo(final Collidable cObject, final Point cPoint, final java.util.List<Collidable> other) {
        this.c = cObject;
        this.collisionPoint = cPoint;
        this.list = other;
    }
    /**
     * The method is an accessor to the collision point.
     * @return The collision point.
     */
    public final Point collisionPoint() { return this.collisionPoint; }

    /**
     * The method is an accessor to the collision object.
     * @return The collision object.
     */
    public final Collidable collisionObject() { return this.c; }

    /**
     * The method sends to appropriate methods based on the size of other collidables list.
     * Built now so i can use material learned in future lectures to extend block to decrease numOfHits for other
     * collidables.
     * @param velocity The Ball's current velocity.
     */
    public final void hitsOtherCollidables(final Velocity velocity) {
        if (this.list.size() == 1) { this.hitsTwoCollidables(velocity); }
        //for (Collidable c : this.list) { ((Block) c).decreaseNumOfHits(); } //DOWNCASTING NOT GOOD BU WILL DO TILL
        //NEXT ASSIGNMENT TO WHEN I CAN EXTEND INTERFACES/CLASSES
    }

    /**
     * The method changes the Ball's velocity if it hits the corner of two collidables.
     * @param velocity The Ball's current velocity.
     */
    private void hitsTwoCollidables(final Velocity velocity) {
        if (this.list.get(0).getCollisionRectangle().lowX() == this.c.getCollisionRectangle().lowX()
                || this.list.get(0).getCollisionRectangle().topX() == this.c.getCollisionRectangle().topX())
        { velocity.verticalChange(); }
        if (this.list.get(0).getCollisionRectangle().lowY() == this.c.getCollisionRectangle().lowY()
                || this.list.get(0).getCollisionRectangle().topY() == this.c.getCollisionRectangle().topY())
        { velocity.horizontalChange(); }
    }

    /**
     * The method returns the number of other object the Ball collides with at this specific intersection point.
     * @return The number of other collidables at this intersection point.
     */
    public final int getOtherCollisionsListSize() { return this.list.size(); }
}
