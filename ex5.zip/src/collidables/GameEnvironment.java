package collidables;
import geometry.Point;
import geometry.Line;
import java.util.ArrayList;
import java.util.List;

/**
 * Defining a GameEnvironment class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class GameEnvironment {

    /**
     * list: The list to store the game's Collidable objects.
     */
    private java.util.List<Collidable> list;

    /**
     * The GameEnvironment's constructor.
     * Creating an empty list to store the game's collidables.
     */
    public GameEnvironment() { this.list = new ArrayList<>(); }

    /**
     * The method adds the Collidable to the list.
     * @param c The Collidable to be added to the list.
     */
    public final void addCollidable(final Collidable c) { this.list.add(c); }

    /**
     * The method removes the Collidable to the list.
     * @param c The Collidable to be removed from the list.
     */
    public final void removeCollidable(final Collidable c) { this.list.remove(c); }

    /**
     * The method returns the CollisionInfo(collision point, collision object and a list of addition collidables with
     * the same collision point) of the Ball's trajectoy with the closest Collidable.
     * @param trajectory The Ball's line of movement.
     * @return The CollisionInfo(collision point, collision object and a list of addition collidables with the same
     * collision point)
     */
    public final CollisionInfo getClosestCollision(final Line trajectory) {
        List<Collidable> copyList = new ArrayList<>(this.list);
        Collidable closestCollidable = null;
        Point closestPoint = new Point(2000, 2000);
        java.util.List<Collidable> collisionPointList = new ArrayList<>();
        for (Collidable c : copyList) {
            Point temp = trajectory.closestIntersectionToStartOfLine(c.getCollisionRectangle());
            if (temp != null) {
                if (trajectory.start().distance(temp) < trajectory.start().distance(closestPoint)) {
                    closestPoint = temp;
                    closestCollidable = c;
                } else if (Math.abs(trajectory.start().distance(temp) - trajectory.start().distance(closestPoint))
                        < 0.001) { collisionPointList.add(c); }
            }
        }
        if (closestCollidable == null) { return null; }
        return new CollisionInfo(closestCollidable, closestPoint, collisionPointList);
    }
}


