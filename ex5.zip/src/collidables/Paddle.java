package collidables;
import game.Ball;
import game.GameLevel;
import sprites.Sprite;
import biuoop.KeyboardSensor;
import biuoop.DrawSurface;
import java.awt.Color;
import geometry.Velocity;
import geometry.Rectangle;
import geometry.Point;
import geometry.Line;

/**
 * Defining a Paddle class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class Paddle implements Sprite, Collidable {

    /**
     * keyboard: The KeyboardSensor to get the user's keyboard control.
     */
    private biuoop.KeyboardSensor keyboard;
    /**
     * paddle: The paddle which is shaped a rectangle.
     */
    private Rectangle paddle;
    /**
     * color: The Paddle's color.
     */
    private Color color;
    /**
     * speed: The Paddle's speed.
     */
    private int speed;

    /**
     * The Block's constructor.
     * @param rect The paddle shape.
     * @param paddleColor The Paddle's color.
     * @param paddleSpeed The Paddle's speed/
     * @param kb The keyboard the Paddle will be controlled by.
     */
    public Paddle(final Rectangle rect, final Color paddleColor, final int paddleSpeed, final KeyboardSensor kb) {
        this.paddle = rect;
        this.color = paddleColor;
        this.speed = paddleSpeed;
        this.keyboard = kb;
    }

    /**
     * The method moves the Paddle to the left.
     */
    public final void moveLeft() {
        if (this.paddle.lowX() - this.speed > 0) {
            this.paddle.setBottomLeft(new Point(this.paddle.lowX() - this.speed, this.paddle.lowY()));
        }
    }
    /**
     * The method moves the Paddle to the right.
     */
    public final void moveRight() {
        if (this.paddle.topX() + this.speed < 800) {
            this.paddle.setBottomLeft(new Point(this.paddle.lowX() + this.speed, this.paddle.lowY()));
        }
    }

    /**
     * The method gets the user controlled keyboard moves.
     */
    @Override
    public final void timePassed() {
        if (keyboard.isPressed(KeyboardSensor.LEFT_KEY)) { this.moveLeft(); }
        if (keyboard.isPressed(KeyboardSensor.RIGHT_KEY)) { this.moveRight(); }
    }
    /**
     * The method draws the Paddle on a given Drawsurface.
     * @param d The given drawSurface which the Paddle will be drawn on.
     */
    @Override
    public final void drawOn(final DrawSurface d) {
        d.setColor(this.color);
        d.fillRectangle(this.paddle.lowX(), this.paddle.lowY(), this.paddle.getWidth(), this.paddle.getHeight());
    }
    @Override
    public final Rectangle getCollisionRectangle() { return this.paddle; }
    @Override
    public final Velocity hit(final Ball ball, final Point collisionPoint, Velocity currentVelocity) {
        int lowX = this.paddle.lowX();
        int lowY = this.paddle.lowY();
        int topX = this.paddle.topX();
        int width = this.paddle.getWidth();
        int count = 0;
        for (int i = lowX; i < lowX + width; i += width / 5) {
            Line line = new Line(i, lowY, i + width / 5, lowY);
            count++;
            if (line.checkRange(collisionPoint)) {
                int angle = 30 * (count + 9);
                if (angle != 360) { currentVelocity = Velocity.fromAngleAndSpeed(angle, this.speed); }
                currentVelocity.verticalChange();
                return currentVelocity;
            }
        }
        if (collisionPoint.getX() == lowX || collisionPoint.getX() == topX) {
            currentVelocity.horizontalChange();
        }  else { currentVelocity.verticalChange(); }
        return currentVelocity;
    }

    /**
     * The method adds the Paddle to the game.
     * @param g The GameLevel object which is passed, so the Paddle can add itself to the relevant members in game.
     */
    public final void addToGame(final GameLevel g) {
        g.addCollidable(this);
        g.addSprite(this);
    }
    /**
     * The method removes the Paddle from the game.
     * @param game The GameLevel object which is passed, so the Paddle can remove itself from the game.
     */
    public final void removeFromGame(final GameLevel game) {
        game.removeCollidable(this);
        game.removeSprite(this);
    }
}
