package annimations;
import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;
/**
 * Defining an AnimationRunner class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class AnimationRunner {
    /**
     * surface: A GUI(screen).
     */
    private GUI surface;
    /**
     * framesPerSecond: The amount of frames to be done every second.
     */
    private int framesPerSecond;
    /**
     * sleeper: The GUI sleeper.
     */
    private Sleeper sleeper;

    /**
     * The AnimationRunner's constructor.
     * Creating a surface(screen), defining the amount of frames per second and initializing the sleeper.
     */
    public AnimationRunner() {
        this.surface = new GUI("Arkanoid", 800, 600);
        this.framesPerSecond = 60;
        this.sleeper = new biuoop.Sleeper();
    }

    /**
     * The method runs the animation loop on a specific animation.
     * @param animation The given animation.
     */
    public final void run(final Animation animation) {
        int millisecondsPerFrame = 1000 / this.framesPerSecond;
        while (!animation.shouldStop()) {
            long startTime = System.currentTimeMillis(); // timing
            DrawSurface d = this.surface.getDrawSurface();
            animation.doOneFrame(d);
            this.surface.show(d);
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) { this.sleeper.sleepFor(milliSecondLeftToSleep); }
        }
    }

    /**
     * The method is an accessor to the animation screen.
     * @return The GUI surface(screen).
     */
    public final GUI getSurface() {
        return surface;
    }
}
