package annimations;
import game.Counter;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import java.awt.Color;
/**
 * Defining a LoseScreen class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class LoseScreen implements Animation {
    /**
     * keyboard: The game's keyboard sensor.
     */
    private KeyboardSensor keyboard;
    /**
     * stopAnimation: A boolean variable indicating to the running of the animation.
     */
    private boolean stopAnimation;
    /**
     * score: A variable to contain the game's score.
     */
    private int score;

    /**
     * The LoseScreen constructor.
     * @param gameScore The game's score counter.
     * @param k The game's keyboard.
     */
    public LoseScreen(final Counter gameScore, final KeyboardSensor k) {
        this.keyboard = k;
        this.score = gameScore.getValue();
        this.stopAnimation = false;
    }

    @Override
    public final boolean shouldStop() {
        return this.stopAnimation;
    }

    @Override
    public final void doOneFrame(final DrawSurface d) {
        d.setColor(Color.BLACK);
        d.fillRectangle(0, 0, 800, 600);
        d.setColor(Color.WHITE);
        d.drawText(200, 330, "\u2620", 430);
        d.drawText(260, 425, "GAME OVER", 50);
        d.drawText(310, 475, "YOUR SCORE:", 25);
        d.drawText(330, 560, "" + this.score , 80);
        if (this.keyboard.isPressed(KeyboardSensor.SPACE_KEY)) { this.stopAnimation = true; }
    }
}
