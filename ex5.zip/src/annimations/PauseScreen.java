package annimations;
import biuoop.KeyboardSensor;
import biuoop.DrawSurface;
import java.awt.Color;

/**
 * Defining a PauseScreen class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class PauseScreen implements Animation {
    /**
     * keyboard: The game's keyboard sensor.
     */
    private KeyboardSensor keyboard;
    /**
     * stop: A boolean variable indicating to the running of the animation.
     */
    private boolean stop;

    /**
     * The PauseScreen's constructor.
     * @param k The keyboard.
     */
    public PauseScreen(final KeyboardSensor k) {
        this.keyboard = k;
        this.stop = false;
    }
    @Override
    public final void doOneFrame(final DrawSurface d) {
        d.setColor(Color.BLACK);
        d.fillRectangle(0, 0, 800, 600);
        d.setColor(Color.WHITE);
        d.fillRectangle(10, 10, 780, 580);
        d.setColor(Color.BLACK);
        d.fillCircle(400, 250, 150);
        d.setColor(Color.WHITE);
        d.fillCircle(400, 250, 140);
        d.setColor(Color.BLACK);
        d.fillCircle(400, 250, 130);
        d.setColor(new Color(223, 150, 240));
        d.fillRectangle(340, 180, 50, 140);
        d.fillRectangle(410, 180, 50, 140);
        d.setColor(Color.BLACK);
        d.drawText(50, 460, "paused -- press space to continue", 45);
        if (this.keyboard.isPressed(KeyboardSensor.SPACE_KEY)) { this.stop = true; }
    }
    @Override
    public final boolean shouldStop() { return this.stop; }
}
