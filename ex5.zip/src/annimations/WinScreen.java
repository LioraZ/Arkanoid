package annimations;
import game.Counter;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import java.awt.Color;
import java.util.Random;

/**
 * Defining a WinScreen class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class WinScreen implements Animation {
    /**
     * keyboard: The game's keyboard sensor.
     */
    private KeyboardSensor keyboard;
    /**
     * stopAnimation: A boolean variable indicating to the running of the animation.
     */
    private boolean stopAnimation;
    /**
     * score: A variable to contain the game's score.
     */
    private int score;

    /**
     * The WinScreen's constructor.
     * @param gameScore The game's score.
     * @param k The game's keyboard.
     */
    public WinScreen(final Counter gameScore, final KeyboardSensor k) {
        this.keyboard = k;
        this.score = gameScore.getValue();
        this.stopAnimation = false;
    }

    @Override
    public final boolean shouldStop() { return this.stopAnimation; }

    @Override
    public final void doOneFrame(final DrawSurface d) {
        d.setColor(Color.BLACK);
        d.fillRectangle(0, 0, 800, 600);
        d.setColor(Color.WHITE);
        d.fillRectangle(10, 10, 780, 580);
        d.setColor(this.generateRandomColor());
        d.fillCircle(400, 300, 240);
        d.setColor(Color.WHITE);
        d.fillCircle(400, 300, 200);
        d.setColor(new Color(223, 150, 240));
        d.setColor(Color.BLACK);
        d.drawText(260, 275, "YOU WON!!!", 50);
        d.drawText(310, 325, "YOUR SCORE:", 25);
        d.drawText(330, 410, "" + this.score , 80);
        if (this.keyboard.isPressed(KeyboardSensor.SPACE_KEY)) { this.stopAnimation = true; }
    }

    /**
     * The method generates a random color and returns it.
     * @return A random color
     */
    public final Color generateRandomColor() {
        Random rand = new Random();
        float r = rand.nextFloat();
        float g = rand.nextFloat();
        float b = rand.nextFloat();
        return new Color(r, g, b);
    }
}
