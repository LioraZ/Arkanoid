package annimations;
import sprites.SpriteCollection;
import biuoop.DrawSurface;
import biuoop.Sleeper;
import java.awt.Color;

/**
 * Defining an CountdownAnimation class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class CountdownAnimation implements Animation {
    /**
     * numOfSeconds: The number of seconds the countdown should last for.
     */
    private double numOfSeconds;
    /**
     * countFrom: The number from which the countdown should start.
     */
    private int countFrom;
    /**
     * sprites: The sprite collection.
     */
    private SpriteCollection sprites;
    /**
     * stopCountdown: A boolean variable to determine the stop of the countdown.
     */
    private boolean stopCountdown;
    /**
     * currentCount: The current number in the countdown.
     */
    private int currentCount;
    /**
     * color: The color of the countdown.
     */
    private Color color;

    /**
     * The Countdown's constructor.
     * The CountdownAnimation will display the given gameScreen, for numOfSeconds seconds, and on top of them it will
     * show a countdown from countFrom back to 1, where each number will appear on the screen for
     * (numOfSeconds / countFrom) seconds, before it is replaced with the next one.
     * @param numSeconds The number of seconds the countdown should last for.
     * @param countF The number from which the countdown should start.
     * @param gameScreen The sprite collection
     * @param countColor The color of the countdown.
     */
    public CountdownAnimation(final double numSeconds, final int countF, final SpriteCollection gameScreen,
                              final Color countColor) {
        this.numOfSeconds = numSeconds;
        this.countFrom = countF;
        this.sprites = gameScreen;
        this.stopCountdown = false;
        this.currentCount = this.countFrom;
        this.color = countColor;
    }
    @Override
    public final void doOneFrame(final DrawSurface d) {
        Sleeper sleeper = new Sleeper();
        this.sprites.drawAllOn(d);
        d.setColor(this.color);
        if (this.currentCount == 0) {
            d.drawText(150, 400, "GO!", 300);
            this.currentCount--;
        } else if (this.currentCount == -1) { this.stopCountdown = true; } else {
            d.drawText(300, 400, this.currentCount + "", 300);
            this.currentCount--;
        }
        sleeper.sleepFor((long) (this.countFrom / this.numOfSeconds) * 1000);

    }
    @Override
    public final boolean shouldStop() { return this.stopCountdown; }
}
