package annimations;
import biuoop.DrawSurface;
/**
 * Defining an Animation Interface.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public interface Animation {
    /**
     * The method does one animation frame using a given DrawSurface.
     * @param d The given DrawSurface
     */
    void doOneFrame(DrawSurface d);

    /**
     * The method returns true if the animation should stop, else it will return false.
     * @return True if the animation should stop, else it will return false.
     */
    boolean shouldStop();
}
