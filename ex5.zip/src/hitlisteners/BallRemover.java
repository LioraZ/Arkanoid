package hitlisteners;

import collidables.Block;
import game.Ball;
import game.Counter;
import game.GameLevel;

/**
 * Defining a BallRemover class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class BallRemover implements HitListener {
    /**
     * game: The gameLevel which this object is defined in.
     */
    private GameLevel game;
    /**
     * remainingBalls: A counter that keeps track of the balls in the game.
     */
    private Counter remainingBalls;

    /**
     * The BallRemover's constructor.
     * @param gameLevel The gameLevel which this object is defined in.
     * @param removedBalls A counter that keeps track of the balls in the game.
     */
    public BallRemover(final GameLevel gameLevel, final Counter removedBalls) {
        this.game = gameLevel;
        this.remainingBalls = removedBalls;
    }

    @Override
    public final void hitEvent(final Block beingHit, final Ball hitter) {
        hitter.removeFromGame(this.game);
        this.remainingBalls.decrease();
    }
}
