package hitlisteners;

import collidables.Block;
import game.Ball;
import game.Counter;

/**
 * Defining a ScoreTrackingListener class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class ScoreTrackingListener implements HitListener {
    /**
     * currentScore: The current game score.
     */
    private Counter currentScore;

    /**
     * The ScoreTrackingListener's constructor.
     * @param scoreCounter The current game score.
     */
    public ScoreTrackingListener(final Counter scoreCounter) {
        this.currentScore = scoreCounter;
    }

    @Override
    public final void hitEvent(final Block beingHit, final Ball hitter) {
        this.currentScore.increase(5);
        if (beingHit.zeroHits()) { this.currentScore.increase(10); }
    }
}
