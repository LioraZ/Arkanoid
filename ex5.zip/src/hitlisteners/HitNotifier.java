package hitlisteners;
/**
 * Defining a HitNotifier Interface.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public interface HitNotifier {
  /**
     * The method ads hl as a listener to hit events.
     * @param hl The hitListener.
     */
    void addHitListener(HitListener hl);
    /**
     * The method removes hl rom the list of listeners to hit events.
     * @param hl The hitListener.
     */
    void removeHitListener(HitListener hl);
}
