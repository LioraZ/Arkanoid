package hitlisteners;
import collidables.Block;
import game.Ball;
import game.Counter;
import game.GameLevel;
import geometry.Velocity;

/**
 * Defining a SplitBall class(A special kind of block that will introduce a new ball whenever it is being hit).
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class SplitBall implements HitListener {
    /**
     * game: The gameLevel which this object is defined in.
     */
    private GameLevel game;
    /**
     * remainingBlocks: A counter that keeps track of the blocks in the game.
     */
    private Counter remainingBlocks;
    /**
     * remainingBalls: A counter that keeps track of the balls in the game.
     */
    private Counter remainingBalls;

    /**
     * The BallRemover's constructor.
     * @param gameLevel The gameLevel which this object is defined in.
     * @param removedBlocks A counter that keeps track of the blocks in the game.
     * @param removedBalls A counter that keeps track of the balls in the game.
     */
    public SplitBall(final GameLevel gameLevel, final Counter removedBlocks, final Counter removedBalls) {
        this.game = gameLevel;
        this.remainingBlocks = removedBlocks;
        this.remainingBalls = removedBalls;
    }

    @Override
    public final void hitEvent(final Block beingHit, final Ball hitter) {
        Ball ball = new Ball(hitter);
        Velocity v1 = Velocity.fromAngleAndSpeed(30, hitter.getVelocity().getSpeed());
        Velocity v2 = Velocity.fromAngleAndSpeed(330, hitter.getVelocity().getSpeed());
        v1.verticalChange();
        v2.verticalChange();
        hitter.setVelocity(v1);
        ball.setVelocity(v2);
        ball.addToGame(game);
        this.remainingBalls.increase();
        if (beingHit.zeroHits()) {
            beingHit.removeHitListener(this);
            beingHit.removeFromGame(this.game);
            this.remainingBlocks.decrease();
        }
    }
}
