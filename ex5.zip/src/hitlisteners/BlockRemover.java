package hitlisteners;

import collidables.Block;
import game.Ball;
import game.Counter;
import game.GameLevel;

/**
 * Defining a BlockRemover class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class BlockRemover implements HitListener {
    /**
     * game: The gameLevel which this object is defined in.
     */
    private GameLevel game;
    /**
     * remainingBlocks: A counter that keeps track of the blocks in the game.
     */
    private Counter remainingBlocks;

    /**
     * The BlockRemover's constructor.
     * @param gameLevel The gameLevel which this object is defined in.
     * @param removedBlocks A counter that keeps track of the blocks in the game.
     */
    public BlockRemover(final GameLevel gameLevel, final Counter removedBlocks) {
        this.game = gameLevel;
        this.remainingBlocks = removedBlocks;
    }

   @Override
    public final void hitEvent(final Block beingHit, final Ball hitter) {
        if (beingHit.zeroHits()) {
            beingHit.removeHitListener(this);
            beingHit.removeFromGame(this.game);
            this.remainingBlocks.decrease();
        }
    }
}
