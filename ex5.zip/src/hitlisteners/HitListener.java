package hitlisteners;

import collidables.Block;
import game.Ball;

/**
 * Defining a HitListener Interface.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public interface HitListener {
    /**
     * The method is called whenever the beingHit object is hit.
     * @param beingHit The block that's being hit.
     * @param hitter The ball that is hitting the block.
     */
    void hitEvent(Block beingHit, Ball hitter);
}
