package hitlisteners;

import collidables.Block;
import game.Ball;
import game.Counter;
import game.GameLevel;

/**
 * Defining a DeathBlock class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class DeathBlock implements HitListener {
    /**
     * game: The gameLevel which this object is defined in.
     */
    private GameLevel game;
    /**
     * remainingBalls: A counter that keeps track of the balls in the game.
     */
    private Counter remainingBalls;
    /**
     * numOfDeaths: The number of times the block should swallow the ball.
     */
    private int numOfDeaths;

    /**
     * The BallRemover's constructor.
     * @param gameLevel The gameLevel which this object is defined in.
     * @param removedBalls A counter that keeps track of the balls in the game.
     * @param numDeaths The number of times the block should swallow the ball.
     */
    public DeathBlock(final GameLevel gameLevel, final Counter removedBalls, final int numDeaths) {
        this.game = gameLevel;
        this.remainingBalls = removedBalls;
        this.numOfDeaths = numDeaths;
    }

    @Override
    public final void hitEvent(final Block beingHit, final Ball hitter) {
        this.numOfDeaths--;
        this.remainingBalls.decrease(1);
        hitter.removeFromGame(this.game);
        if (this.numOfDeaths == 0) { beingHit.removeHitListener(this); }
    }
}

