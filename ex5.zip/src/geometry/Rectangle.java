package geometry;
import java.util.ArrayList;

/**
 * Defining a Rectangle class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class Rectangle {

    /**
     * topRight: The Rectangle's top-right Point.
     */
    private Point topRight;
    /**
     * bottomLeft: The Rectangle's bottom-left Point.
     */
    private Point bottomLeft;

    /**
     * The Rectangle's constructor.
     * @param left The x value of the Frame's bottomLeft Point.
     * @param bottom The y value of the Frame's bottomLeft Point.
     * @param right The x value of the Frame's topRight Point.
     * @param top The y value of the Frame's topRight Point.
     */
    public Rectangle(final double left, final double bottom, final double right, final double top) {
        this.topRight = new Point(java.lang.Math.max(right, left), java.lang.Math.max(top, bottom));
        this.bottomLeft = new Point(java.lang.Math.min(right, left), java.lang.Math.min(top, bottom));
    }

    /**
     * The Rectangle's constructor.
     * @param point The Rectangle's closest Point to the start of the screen.
     * @param width The Rectangle's width.
     * @param height The Rectangle's height.
     */
    public Rectangle(final Point point, final int width, final int height) { this(point.getX(),
            point.getY(), point.getX() + width, point.getY() + height); }

    /**
     * The method returns the width of the rectangle.
     * @return The width of the rectangle.
     */
    public final int getWidth() { return (int) (this.topRight.getX() - this.bottomLeft.getX()); }
    /**
     * The method returns the height of the rectangle.
     * @return The height of the rectangle.
     */
    public final int getHeight() { return (int) (this.topRight.getY() - this.bottomLeft.getY()); }

    /**
     * The method returns the lowest x value bound (which is the x value of the bottomLeft Point).
     * @return The x value of the bottomLeft Point.
     */
    public final int lowX() { return (int) this.bottomLeft.getX(); }
    /**
     * The method returns the lowest y value bound (which is the y value of the bottomLeft Point).
     * @return The y value of the bottomLeft Point.
     */
    public final int lowY() { return (int) this.bottomLeft.getY(); }

    /**
     * The method returns the highest x value bound (which is the x value of the topRight Point).
     * @return The x value of the topRight Point.
     */
    public final int topX() { return (int) this.topRight.getX(); }
    /**
     * The method returns the highest y value bound (which is the y value of the topRight Point).
     * @return The y value of the topRight Point.
     */
    public final int topY() { return (int) this.topRight.getY(); }

    /**
     * The method returns the Lines making up the Rectangle.
     * @return An array of Lines making up the Rectangle.
     */
    public final Line [] getRectangleLines() {
        Line [] lines = new Line[4];
        lines[0] = new Line(this.lowX(), this.topY(), this.topX(), this.topY());
        lines[1] = new Line(this.lowX(), this.lowY(), this.topX(), this.lowY());
        lines[2] = new Line(this.topX(), this.lowY(), this.topX(), this.topY());
        lines[3] = new Line(this.lowX(), this.lowY(), this.lowX(), this.topY());
        return lines;
    }

    /**
     * The method returns a list of intersection points between a given line and the rectangle.
     * @param line The given lie which intersection with is checked.
     * @return A list of intersection points between a given line and the rectangle.
     */
    public final java.util.List<Point> intersectionPoints(final Line line) {
        java.util.List<Point> list = new ArrayList<>();
        Line [] lines = this.getRectangleLines();
        for (Line rectLine: lines) {
            Point intersection = line.intersectionWith(rectLine);
            if (intersection != null && !list.contains(intersection)) {
                list.add(intersection);
            }
        }
        return list;
    }

    /**
     * The method sets a new bottomLeft Point.
     * @param point The new bottomLeft Point.
     */
    public final void setBottomLeft(final Point point) {
        int width = this.getWidth();
        int height = this.getHeight();
        this.bottomLeft = point;
        this.topRight = new Point(this.lowX() + width, this.lowY() + height);
    }
}
