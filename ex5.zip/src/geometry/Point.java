package geometry;
import java.text.DecimalFormat;

/**
 * Defining a Point class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class Point {

    /**
     * x: containing the Point's x value.
     */
    private double x;
    /**
     * y: containing the Point's y value.
     */
    private double y;

    /**
     * The Point's constructor.
     *
     * @param xVal The x value of the point.
     * @param yVal The y value of the point.
     */
    public Point(final double xVal, final double yVal) {
        this.x = xVal;
        this.y = yVal;
    }

    /**
     * The method returns the distance of this point to the other point.
     *
     * @param other The other point which the distance is measured from.
     * @return The distance between both Points.
     */
    public final double distance(final Point other) {
        double powX = java.lang.Math.pow(this.x - other.getX(), 2);
        double powY = java.lang.Math.pow(this.y - other.getY(), 2);
        return Math.sqrt(powX + powY);
    }

    /**
     * The method returns true is the points are equal, false otherwise.
     *
     * @param other The other point which it value is commpared to.
     * @return true if points are equal, false otherwise.
     */
    public final boolean equals(final Point other) {
        return ((other.getX() == this.x) && (other.getY() == this.y));
    }

    /**
     * The method returns the x value of the point.
     *
     * @return The x value of the point.
     */
    public final double getX() {
        return this.x;
    }

    /**
     * The method returns the y value of the point.
     *
     * @return The y value of the point.
     */
    public final double getY() {
        return this.y;
    }

    /**
     * The method returns true is the the current Point is has larger values than other, false otherwise.
     *
     * @param other The other point which it values are compared with.
     * @return true if current Point has larger values than other, false otherwise.
     */
    public final boolean isBigger(final Point other) {
        return ((this.x >= other.getX()) && (this.y >= other.getY()));
    }

    /**
     * The method rounds the x,y values of the Point till 2-3 decimal points.
     */
    public final void round() {
        DecimalFormat df = new DecimalFormat("0.000");
        this.x = Double.parseDouble(df.format(this.x));
        this.y = Double.parseDouble(df.format(this.y));
    }
}

