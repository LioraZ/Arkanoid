package geometry;
/**
 * Defining a Point class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class Line {
    /**
     * start: containing the Line's start Point.
     */
    private Point start;
    /**
     * end: containing the Line's end Point.
     */
    private Point end;
    /**
     * function: containing the corresponding Function to the Line.
     */
    private Function function;

    /**
     * The method constructs the Line.
     * The direction of the Line is currently irrelevant, therefore the start Point will have a lower value than the
     * end Point.
     * @param startPoint The first Point in the Line.
     * @param endPoint The second Point in the Line.
     */
    public Line(final Point startPoint, final Point endPoint) {
        if (startPoint.equals(endPoint)) { throw new RuntimeException("Points are equal"); }
        this.start = startPoint;
        this.end = endPoint;
        this.function = new Function(this.start, this.end);
    }

    /**
     * The method constructs the Point.
     * @param x1 The x value of the start Point.
     * @param y1 The y value of the start Point.
     * @param x2 The x value of the end Point.
     * @param y2 The y value of the end Point.
     */
    public Line(final double x1, final double y1, final double x2, final double y2) { this(new
                    Point(x1, y1), new Point(x2, y2)); }

    /**
     * The method returns the length of the line which is calculated to be the distance between both Points.
     * @return The length of the Line.
     */
    public final double length() { return this.start.distance(this.end); }

    /**
     * The method returns middle Point of the Line.
     * @return The middle Point.
     */
    public final Point middle() {
        double middleX = (this.start.getX() + this.end.getX()) / 2;
        double middleY = (this.start.getY() + this.end.getY()) / 2;
        return new Point(middleX, middleY);
    }

    /**
     * The method returns the start Point of the Line.
     * @return The start Point.
     */
    public final Point start() { return this.start; }

    /**
     * The method returns the end Point of the Line.
     * @return The end Point.
     */
    public final Point end() {
        return this.end;
    }

    /**
     * The method returns the corresponding Function to the Line.
     * @return The corresponding Function.
     */
    public final Function getFunction() { return this.function; }

    /**
     * The method returns true if both the Lines intersect, and false otherwise.
     * @param other The other Line which intersection with is checked.
     * @return true if both the Lines intersect, and else false.
     */
    public final boolean isIntersecting(final Line other) { return (this.intersectionWith(other) != null); }

    /**
     * The method returns the intersection Poit between both Lines if it exists, and null if there is no such Point.
     * @param other The other Line which intersection with is checked.
     * @return The intersection Point or null if such Point doesn't exist.
     */
    public final Point intersectionWith(final Line other) {
        Point intersectionPoint = this.function.intersectionPoint(other.getFunction());
        if ((intersectionPoint == null) || (!this.inRange(intersectionPoint, other)) || (this.equals(other))
                || (this.flipLine().equals(other))) { return null; }
        if (this.function.equals(other.getFunction())) { return this.linesTouching(other); }
        return intersectionPoint;
    }

    /**
     * The method returns the intersection Point between both Lines if it exists, and null if there is no such Point.
     * @param other The other Line which intersection with is checked.
     * @return The intersection Point or null if such Point doesn't exist.
     */
    public final Point linesTouching(final Line other) {
        if (this.start.equals(other.end())) {
            if (this.end.isBigger(this.start) && other.end().isBigger(other.start())) { return this.start; }
            if (this.start.isBigger(this.end) && other.start().isBigger(other.end())) { return this.start; }
            return null;
        }
        if (this.end.equals(other.start())) {
            if (this.end.isBigger(this.start) && other.end().isBigger(other.start())) { return this.end; }
            if (this.start.isBigger(this.end) && other.start().isBigger(other.end())) { return this.end; }
            return null;
        }
        if (this.start.equals(other.start())) {
            if (this.start.isBigger(this.end) && other.end().isBigger(other.start())) { return this.start; }
            if (this.start.isBigger(this.end) && other.end().isBigger(other.start())) { return this.start; }
        }
        if (this.end.equals(other.end())) {
            if (this.start.isBigger(this.end) && other.end().isBigger(other.start())) { return this.end; }
            if (this.start.isBigger(this.end) && other.end().isBigger(other.start())) { return this.end; }
        }
        return null;
    }

    /**
     * The method returns true if the lines are equal, and false otherwise.
     * @param other The other Line which the current Line is compared with.
     * @return true if the lines are equal, and false otherwise.
     */
    public final boolean equals(final Line other) { return (this.start.equals(other.start())
            && (this.end.equals(other.end()))); }

    /**
     * The method returns true if the Point is on the Line, and false otherwise.
     * @param point The Point that is checked.
     * @return true if the Point is on the Line, and false otherwise.
     */
    public final boolean checkRange(final Point point) {
        point.round();
        double x = point.getX();
        double y = point.getY();
        double maxXRange = Math.max(this.start.getX(), this.end.getX());
        double maxYRange = Math.max(this.start.getY(), this.end.getY());
        double minXRange = Math.min(this.start.getX(), this.end.getX());
        double minYRange = Math.min(this.start.getY(), this.end.getY());
        if ((x > maxXRange) || (x < minXRange)) { return false; }
        return (y >= minYRange) && (y <= maxYRange);
    }

    /**
     * The method returns true if the Point is the intersection Point between the Lines, and false otherwise.
     * @param point The Point that is checked.
     * @param line The Line which is checked.
     * @return true if the Point is the intersection Point between the Lines, and false otherwise.
     */
    public final boolean inRange(final Point point, final Line line) { return (this.checkRange(point)
            && line.checkRange(point)); }

    /**
     * The method returns a new Line with opposite(flipped) start and end Points.
     * @return A new Line with opposite start and end Points.
     */
    public final Line flipLine() { return new Line(this.end, this.start); }

    /**
     * The method returns the closest intersection Point to the start of the line with the given rectangle, and null
     * if there is no such Point.
     * @param rect The given rectangle to calculate the closest intersection Point of this Line to it.
     * @return The Line's closest intersection Point to the rectangle, and null if there is no sch Point.
     */
    public final Point closestIntersectionToStartOfLine(final Rectangle rect) {
        java.util.List<Point> list = rect.intersectionPoints(this);
        if (list.isEmpty()) { return null; }
        if (list.size() == 1) { return list.get(0); }
        if (list.get(0).distance(this.start()) < list.get(1).distance(this.start())) { return list.get(0); }
        return list.get(1);
    }
}
