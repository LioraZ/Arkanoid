package geometry;
/**
 * Defining a Function class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class Function {

    /**
     * slope: The slope value of the Function.
     */
    private double slope;
    /**
     * constant: The constant value of the Function.
     */
    private double constant;
    /**
     * parallelToY: contains a boolean value of whether the function is parallel to the y line.
     */
    private boolean parallelToY;

    /**
     * The Function's constructor.
     * @param p1 A Point on the Function.
     * @param p2 A Point on the Function.
     */
    public Function(final Point p1, final Point p2) {
        if (p1.getX() - p2.getX() == 0) {
            parallelToY = true;
            this.slope = 1;
            this.constant = p1.getX();
        } else {
            parallelToY = false;
            this.slope = (p1.getY() - p2.getY()) / (p1.getX() - p2.getX());
            this.constant = p1.getY() - this.slope * p1.getX();
        }
    }

    /**
     * The method returns true if the Functions are intersection, and else false.
     * @param f The Function which intersection with is checked.
     * @return true if the Functions intersect, and else false.
     */
    public final boolean isIntersecting(final Function f) {
        if (this.slope != f.getSlope()) { return true; }
        if (this.parallelToY != f.isParallelToY()) { return true; }
        return this.constant == f.constant;
    }

    /**
     * The method returns the intersection Point between both function, and null if there isn't such a Point.
     * @param f The Function which intersection with is checked.
     * @return The intersection Point if such a Point exists and else null.
     */
    public final Point intersectionPoint(final Function f) {
        if (!this.isIntersecting(f) || this.equals(f)) { return null; }
        if (this.parallelToY) { return new Point(this.constant, this.constant * f.getSlope() + f.getConstant()); }
        if (f.isParallelToY()) { return new Point(f.getConstant(), f.getConstant() * this.slope + this.constant); }
        double x = (f.getConstant() - this.constant) / (this.slope - f.getSlope());
        double y = this.slope * x + this.constant;
        return new Point(x, y);
    }

    /**
     * The method returns the Function's slope value.
     * @return The Function's slope value.
     */
    public final double getSlope() { return this.slope; }

    /**
     * The method returns the Function's constant value.
     * @return The Function's constant value.
     */
    public final double getConstant() { return this.constant; }

    /**
     * The method returns the Function's parallelToY boolean value.
     * @return The Function's parallelToY boolean value.
     */
    public final boolean isParallelToY() { return this.parallelToY; }

    /**
     * The method checks if both functions are equal and returns an appropriate boolean expression.
     * @param f The other Function to be compared with.
     * @return true if both Functions are equal and else false.
     */
    public final boolean equals(final Function f) {
        return (this.slope == f.getSlope()) && (this.constant == f.getConstant())
                && (this.parallelToY == f.isParallelToY());
    }
}
