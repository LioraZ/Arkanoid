package geometry;
import java.text.DecimalFormat;

/**
 * Defining a Velocity class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class Velocity {
    /**
     * dx: containing the Velocity's change-to-the-x value.
     */
    private double dx;
    /**
     * dy: containing the Velocity's change-to-the-y value.
     */
    private double dy;

    /**
     * The Velocity's constructor.
     * @param dxVelocity The dx value of the Velocity's movement.
     * @param dyVelocity The dy value of the Velocity's movement.
     */
    public Velocity(final double dxVelocity, final double dyVelocity) {
        this.dx = dxVelocity;
        this.dy = dyVelocity;
    }

    /**
     * The Velocity's default constructor- to no movement.
     */
    public Velocity() { this(0, 0); }

    /**
     * The Velocity's static constructor.
     * @param angle The movement angle.
     * @param speed The movement speed.
     * @return A new Velocity translated dx, dy values from the speed and angle.
     */
    public static Velocity fromAngleAndSpeed(final double angle, final double speed) {
        DecimalFormat df = new DecimalFormat("0.000");
        double dx = speed * java.lang.Math.sin(Math.toRadians(angle));
        double dy = speed * java.lang.Math.cos(Math.toRadians(angle));
        dx = Double.parseDouble(df.format(dx));
        dy = Double.parseDouble(df.format(dy));
        return new Velocity(dx, dy);
    }

    /**
     * The method applies the Velocity(movement) to the given Point.
     * @param p The Point the Velocity is applied to.
     * @return A new Point which the new Velocity(movement0 was applied to.
     */
    public final Point applyToPoint(final Point p) { return new Point(p.getX() + dx, p.getY() + dy); }

    /**
     * The method changes the Velocity horizontally.
     */
    public final void horizontalChange() { this.dx = -dx; }
    /**
     * The method changes the Velocity vertically.
     */
    public final void verticalChange() { this.dy = -dy; }

    /**
     * The method accesses the Velocity dx field.
     * @return The Velocity's dx.
     */
    public final double getDx() { return this.dx; }

    /**
     * The method accesses the Velocity dy field.
     * @return The Velocity's dy.
     */
    public final double getDy() { return dy; }

    /**
     * The method is an access or to the Velocity's speed.
     * @return The velocitiy's speed.
     */
    public final double getSpeed() { return this.dx / (Math.sin(Math.atan(this.dx / this.dy))); }
}
