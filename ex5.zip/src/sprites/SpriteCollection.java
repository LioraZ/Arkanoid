package sprites;
import java.util.ArrayList;
import java.util.List;

import biuoop.DrawSurface;

/**
 * Defining a SpriteCollection class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class SpriteCollection {

    /**
     * list: The list to store the game's sprites.
     */
    private java.util.List<Sprite> list;

    /**
     * The SpriteCollection's constructor.
     * Creating an empty list to store the game's sprites.
     */
    public SpriteCollection() { this.list = new ArrayList<>(); }

    /**
     * The method adds the given Sprite to the list.
     * @param s The Sprite to be added to the list.
     */
    public final void addSprite(final Sprite s) { this.list.add(s); }

    /**
     * The method removes the given Sprite from the list.
     * @param s The Sprite to be removed from the list.
     */
    public final void removeSprite(final Sprite s) { this.list.remove(s); }

    /**
     * The method notifies all the sprites in the list that timePassed().
     */
    public final void notifyAllTimePassed() {
        List<Sprite> copyList = new ArrayList<>(this.list);
        for (Sprite sprite : copyList) { sprite.timePassed(); }
    }

    /**
     * The method calls drawOn(d) on all sprites with a given DrawSurface.
     * @param d The given DrawSurface which is sent to each Sprite's drawOn method.
     */
    public final void drawAllOn(final DrawSurface d) {
        List<Sprite> copyList = new ArrayList<>(this.list);
        for (Sprite sprite : copyList) { sprite.drawOn(d); }
    }
}
