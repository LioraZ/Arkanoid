package sprites;
import game.Counter;
import game.GameLevel;
import biuoop.DrawSurface;
import java.awt.Color;

/**
 * Defining a ScoreIndicator class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class ScoreIndicator implements Sprite {
    /**
     * score: The game's score.
     */
    private Counter score;

    /**
     * The ScoreIndicator's constructor.
     * @param scoreCounter A counter keeping track f the score.
     */
    public ScoreIndicator(final Counter scoreCounter) { this.score = scoreCounter; }

    @Override
    public final void drawOn(final DrawSurface d) {
        d.setColor(Color.WHITE);
        d.drawText(390, 16, "Score: " + score.getValue(), 15);
    }

    @Override
    public final void timePassed() { }

    /**
     * The method adds the ScoreIndicator to the gameLevel.
     * @param game The gameLevel to be added to.
     */
    public final void addToGame(final GameLevel game) { game.addSprite(this); }
}
