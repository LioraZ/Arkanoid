package sprites;
import game.Counter;
import game.GameLevel;
import biuoop.DrawSurface;
import java.awt.Color;

/**
 * Defining a LivesIndicator class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class LivesIndicator implements Sprite {
    /**
     * numLives: A counter tracking the number of lives in the game.
     */
    private Counter numLives;

    /**
     * The LivesIndicator's constructor.
     * @param numOfLives The number of lives in th game.
     */
    public LivesIndicator(final Counter numOfLives) { this.numLives = numOfLives; }
    @Override
    public final void timePassed() { }

    @Override
    public final void drawOn(final DrawSurface d) {
        d.setColor(Color.RED);
        d.drawText(600, 18, "\u2665", 20);
        d.setColor(Color.WHITE);
        d.drawText(615, 16, " X " + numLives.getValue(), 15);
    }

    /**
     * The method adds the LivesIndicator to the gameLevel.
     * @param game The gameLevel to be added to.
     */
    public final void addToGame(final GameLevel game) { game.addSprite(this); }
}
