package sprites;
import biuoop.DrawSurface;

/**
 * Defining a Sprite Interface.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public interface Sprite {

    /**
     * The method draws the Sprite on a given Drawsurface.
     * @param d The given drawSurface which the Sprite will be drawn on.
     */
    void drawOn(DrawSurface d);

    /**
     * The method notifies the Sprite that time has passed.
     */
    void timePassed();
}
