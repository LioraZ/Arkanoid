package sprites;
import game.GameLevel;
import biuoop.DrawSurface;
import java.awt.Color;

/**
 * Defining a LevelIndicator class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class LevelIndicator implements Sprite {
    /**
     * level: The level's name.
     */
    private String level;

    /**
     * The LevelIndicator's constructor.
     * @param levelName The level's name.
     */
    public LevelIndicator(final String levelName) { this.level = levelName; }

    @Override
    public final void timePassed() { }

    @Override
    public final void drawOn(final DrawSurface d) {
        d.setColor(Color.WHITE);
        d.drawText(170, 16, "Level: " + level, 15);
    }

    /**
     * The method adds the LevelIndicator to the gameLevel.
     * @param game The gameLevel to be added to.
     */
    public final void addToGame(final GameLevel game) { game.addSprite(this); }
}
