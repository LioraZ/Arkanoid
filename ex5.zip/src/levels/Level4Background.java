package levels;
import sprites.Sprite;
import biuoop.DrawSurface;
import java.awt.Color;

/**
 * Defining the Level4Background class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class Level4Background implements Sprite {
    /**
     * line1Movement: The y-value that determines the top line's movement.
     */
    private int line1Movement;
    /**
     * line2Movement: The y-value that determines the bottom line's movement.
     */
    private int line2Movement;
    /**
     * count: A counter that keeps track of the movement.
     */
    private int count;

    /**
     * The Level4Background constructor.
     */
    public Level4Background() {
        this.line1Movement = 120;
        this.line2Movement = 315;
        this.count = 0;
    }
    @Override
    public final void drawOn(final DrawSurface d) {
        d.setColor(Color.BLUE);
        d.fillRectangle(10, this.line1Movement, 780, 15);
        d.fillRectangle(10, this.line2Movement, 780, 15);
        String starOfDavid = "\u2721";
        d.drawText(300, 315, starOfDavid, 250);
    }

    @Override
    public final void timePassed() {
        if (this.count == 80) { this.count = 0; }
        if (this.count <  40) {
            this.line1Movement -= 2;
            this.line2Movement += 2;
            count++;
        }
        if (this.count >= 40) {
            this.line1Movement += 2;
            this.line2Movement -= 2;
            count++;
        }
    }
}
