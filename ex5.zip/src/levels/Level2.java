package levels;
import collidables.Block;
import sprites.Sprite;
import geometry.Point;
import geometry.Velocity;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * Defining the Level2 class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class Level2 implements LevelInformation {
    @Override
    public final int numberOfBalls() { return 8; }
    @Override
    public final List<Velocity> initialBallVelocities() {
        List<Velocity> velocityList = new ArrayList<>();
        for (int i = 0; i < this.numberOfBalls(); i++) {
            velocityList.add(Velocity.fromAngleAndSpeed(300 + 120 / (this.numberOfBalls() + 1) * (i + 1),
                    this.paddleSpeed()));
        }
        return velocityList;
    }
    @Override
    public final int paddleSpeed() { return 8; }
    @Override
    public final int paddleWidth() { return 600; }
    @Override
    public final String levelName() { return "Hearty Hard"; }
    @Override
    public final Sprite getBackground() { return new Level2Background(); }
    @Override
    public final List<Block> blocks() {
        List<Block> blockList = new ArrayList<>();
        int width = 60;
        for (int i = 10; i <= 790 - width; i += width) {
            blockList.add(new Block(new Point(i, 200), width, 40, Color.BLACK, 1));
        }
        return blockList;
    }
    @Override
    public final int numberOfBlocksToRemove() { return this.blocks().size(); }

    @Override
    public final Color getCountdownColor() {
        return new Color(255, 200, 255);
    }

    @Override
    public final List<Block> getBlocksThatSplitBall() { return new ArrayList<>(); }

    @Override
    public final List<Block> getDeathBlocks() {
        return new ArrayList<>();
    }
}
