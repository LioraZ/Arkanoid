package levels;
import game.Ball;
import sprites.Sprite;
import biuoop.DrawSurface;
import geometry.Velocity;
import java.awt.Color;

/**
 * Defining the Level3Background class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class Level3Background implements Sprite {
    /**
     * flowerCircles: An array of balls that when drawn are in the shape of a flower.
     */
    private Ball[] flowerCircles = new Ball[7];
    /**
     * velocity: The velocity for the flower.
     */
    private Velocity velocity;

    /**
     * The Level#Background constructor.
     */
    public Level3Background() {
        this.velocity = Velocity.fromAngleAndSpeed(90, 2);
        Color color = new Color(173, 70, 150);
        flowerCircles[0] = new Ball(350, 390, 30, color, null);
        flowerCircles[1] = new Ball(450, 390, 30, color, null);
        flowerCircles[2] = new Ball(375, 345, 30, color, null);
        flowerCircles[3] = new Ball(425, 345, 30, color, null);
        flowerCircles[4] = new Ball(375, 435, 30, color, null);
        flowerCircles[5] = new Ball(425, 435, 30, color, null);
        flowerCircles[6] = new Ball(400, 390, 30, new Color(173, 100, 180), null);
        for (Ball circle: this.flowerCircles) { circle.setVelocity(velocity); }
        //new Color(100, 10, 100);
    }

    @Override
    public final void drawOn(final DrawSurface d) {
        for (int i = 10; i < 790; i += 5) {
            if (i % 20 == 0) { d.setColor(new Color(113, 170, 255)); } else { d.setColor(Color.WHITE); }
            d.fillRectangle(i, 20, 20, 600);
        }
        d.setColor(new Color(113, 170, 255));
        d.fillRectangle(0, 385, 800, 10);
        for (Ball circle: this.flowerCircles) {
            circle.drawOn(d);
            d.setColor(new Color(173, 100, 180));
            d.fillCircle((int) circle.getCenter().getX(), (int) circle.getCenter().getY(), 5);
        }
    }

    @Override
    public final void timePassed() {
        if (this.flowerCircles[1].getCenter().getX() >= 790 - flowerCircles[1].getSize()) {
            this.velocity = Velocity.fromAngleAndSpeed(270, 2);
            this.changeVelocity();
        }
        if (this.flowerCircles[0].getCenter().getX() <= 10 + flowerCircles[0].getSize()) {
            this.velocity = Velocity.fromAngleAndSpeed(90, 2);
            this.changeVelocity();
        }
        for (Ball circle: this.flowerCircles) {
            circle.setCenter(circle.getVelocity().applyToPoint(circle.getCenter()));
        }
    }

    /**
     * The method changes the balls making up the flowers velocities.
     */
    private void changeVelocity() {
        for (Ball circle: this.flowerCircles) { circle.setVelocity(this.velocity); }
    }
}
