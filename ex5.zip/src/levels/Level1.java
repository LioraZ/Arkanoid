package levels;
import collidables.Block;
import sprites.Sprite;
import geometry.Velocity;
import geometry.Point;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * Defining the Level1 class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class Level1 implements LevelInformation {
    @Override
    public final int numberOfBalls() {
        return 1;
    }
    @Override
    public final List<Velocity> initialBallVelocities() {
        List<Velocity> velocityList = new ArrayList<>();
        velocityList.add(Velocity.fromAngleAndSpeed(0, this.paddleSpeed()));
        return velocityList;
    }
    @Override
    public final int paddleSpeed() { return 10; }
    @Override
    public final int paddleWidth() { return 150; }
    @Override
    public final String levelName() { return "Direct Hit"; }
    @Override
    public final Sprite getBackground() { return new Level1Background(); }
    @Override
    public final List<Block> blocks() {
        List<Block> blockList = new ArrayList<>();
        blockList.add(new Block(new Point(370, 200), 60, 60, Color.BLACK, 1));
        return blockList;
    }
    @Override
    public final int numberOfBlocksToRemove() { return this.blocks().size(); }

    @Override
    public final Color getCountdownColor() { return new Color(255, 100, 100); }

    @Override
    public final List<Block> getBlocksThatSplitBall() {
        return new ArrayList<>();
    }

    @Override
    public final List<Block> getDeathBlocks() {
        return new ArrayList<>();
    }
}
