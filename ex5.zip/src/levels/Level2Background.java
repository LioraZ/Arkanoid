package levels;
import sprites.Sprite;
import biuoop.DrawSurface;
import java.awt.Color;

/**
 * Defining the Level2Background class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class Level2Background implements Sprite {
    @Override
    public final void drawOn(final DrawSurface d) {
        for (int i = 10; i < 790; i += 10) {
            if (i % 20 == 0) { d.setColor(Color.WHITE); } else { d.setColor(new Color(223, 150, 240)); }
            d.fillRectangle(i, 20, 20, 600);
        }
        d.setColor(Color.BLACK);
        char hollowHeart = '\u2661';
        d.drawText(230, 400, "" + hollowHeart, 500);
    }

    @Override
    public final void timePassed() { }
}
