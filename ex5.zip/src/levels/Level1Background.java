package levels;
import biuoop.DrawSurface;
import sprites.Sprite;
import java.awt.Color;

/**
 * Defining the Level1Background class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class Level1Background implements Sprite {
    @Override
    public final void drawOn(final DrawSurface d) {
        d.setColor(Color.BLACK);
        for (int i = 10; i < 790; i += 60) { d.drawLine(i, 20, i, 600); }
        for (int i = 20; i < 600; i += 60) { d.drawLine(10, i, 790, i); }
        Color color = new Color(255, 200, 200);
        d.setColor(color);
        int count1 = 0, count2 = 0;
        for (int i  = 25; i < 790; i += 30) {
            count1++;
            if (count1 % 2 == 0) { continue; }
            for (int j = 35; j < 600; j += 30) {
                count2++;
                if (count2 % 2 == 0) { continue; }
                d.fillRectangle(i, j, 30, 30);
            }
            count2 = 0;
        }
        d.setColor(Color.BLACK);
        d.fillRectangle(310, 140, 10, 180);
        d.fillRectangle(310, 140, 180, 10);
        d.fillRectangle(310, 310, 180, 10);
        d.fillRectangle(480, 140, 10, 180);
    }

    @Override
    public final void timePassed() { }
}
