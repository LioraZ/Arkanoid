package levels;
import collidables.Block;
import sprites.Sprite;
import geometry.Velocity;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * Defining the Level3 class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class Level3 implements LevelInformation {
    @Override
    public final int numberOfBalls() { return 2; }

    @Override
    public final int numberOfBlocksToRemove() {
        return 45;
    }

    @Override
    public final int paddleSpeed() {
        return 10;
    }

    @Override
    public final int paddleWidth() {
        return 150;
    }

    @Override
    public final List<Block> blocks() {
        List<Block> blockList = new ArrayList<>();
        Color color = new Color(173, 50, 130);
        for (int i = 150; i < 650; i += 50) {
            Block block = new Block(new geometry.Point(i, 120), 50, 30, color, 2);
            blockList.add(block);
        }
        color = new Color(173, 70, 150);
        for (int i = 175; i < 625; i += 50) {
            Block block = new Block(new geometry.Point(i, 150), 50, 30, color, 1);
            blockList.add(block);
        }
        color = new Color(173, 100, 180);
        for (int i = 200; i < 600; i += 50) {
            Block block = new Block(new geometry.Point(i, 180), 50, 30, color, 1);
            blockList.add(block);
        }
        color = new Color(173, 130, 210);
        for (int i = 225; i < 575; i += 50) {
            Block block = new Block(new geometry.Point(i, 210), 50, 30, color, 1);
            blockList.add(block);
        }
        color = new Color(153, 150, 240);
        for (int i = 250; i < 550; i += 50) {
            Block block = new Block(new geometry.Point(i, 240), 50, 30, color, 1);
            blockList.add(block);

        }
        color = new Color(113, 170, 255);
        for (int i = 275; i < 525; i += 50) {
            Block block = new Block(new geometry.Point(i, 270), 50, 30, color, 1);
            blockList.add(block);
        }
        return blockList;
    }

    @Override
    public final List<Velocity> initialBallVelocities() {
        List<Velocity> velocityList = new ArrayList<>();
        velocityList.add(0, Velocity.fromAngleAndSpeed(300, this.paddleSpeed()));
        velocityList.add(1, Velocity.fromAngleAndSpeed(60, this.paddleSpeed()));
        return velocityList;
    }

    @Override
    public final Sprite getBackground() {
        return new Level3Background();
    }

    @Override
    public final String levelName() {
        return "Flower Power";
    }

    @Override
    public final Color getCountdownColor() {
        return Color.BLACK;
    }

    @Override
    public final List<Block> getBlocksThatSplitBall() { return new ArrayList<>(); }

    @Override
    public final List<Block> getDeathBlocks() {
        return new ArrayList<>();
    }
}
