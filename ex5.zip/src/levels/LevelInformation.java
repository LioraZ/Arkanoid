package levels;
import collidables.Block;
import sprites.Sprite;
import geometry.Velocity;
import java.awt.Color;
import java.util.List;
/**
 * Created by Liora on 28-May-17.
 */
public interface LevelInformation {
    /**
     * The method returns the number of initial balls in the level.
     * @return The number of initial balls in the level.
     */
    int numberOfBalls();
    /**
     * The method returns the initial velocities of the balls in the level.
     * @return The initial velocities of the balls in the level.
     */
    List<Velocity> initialBallVelocities();

    /**
     * The method returns the level's paddle speed.
     * @return The level's paddle speed.
     */
    int paddleSpeed();

    /**
     * The method returns the level's paddle width.
     * @return The level's paddle width.
     */
    int paddleWidth();

    /**
     * The method returns the level's name(that will be displayed at the top of the screen).
     * @return The level's name.
     */
    String levelName();

    /**
     * The method returns a sprite with the background of the level.
     * @return A sprite with the background of the level.
     */
    Sprite getBackground();

    /**
     * The method creates the level's blocks and returns them.
     * @return A list of the level's blocks.
     */
    List<Block> blocks();
    /**
     * The method returns the number of blocks that should be removed in the level, before the level is considered to
     * be cleared. This number should be <= blocks.size().
     * @return The number of blocks that should be removed in the level.
     */
    int numberOfBlocksToRemove();

    /**
     * The method returns the color of the countdown animation in order for it to be seen on the level's background.
     * @return A color for the countdown animation.
     */
    Color getCountdownColor();

    /**
     * The method creates the level's blocks that introduce new balls and returns them.
     * @return A list of the level's above  blocks.
     */
    List<Block> getBlocksThatSplitBall();
    /**
     * The method creates the level's blocks that swallow balls and returns them.
     * @return A list of the level's above blocks.
     */
    List<Block> getDeathBlocks();
}
