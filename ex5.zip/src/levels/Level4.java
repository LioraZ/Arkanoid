package levels;
import collidables.Block;
import sprites.Sprite;
import geometry.Point;
import geometry.Velocity;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * Defining the Level4 class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class Level4 implements LevelInformation {

    @Override
    public final int numberOfBalls() {
        return 5;
    }
    @Override
    public final List<Velocity> initialBallVelocities() {
        List<Velocity> velocityList = new ArrayList<>();
        for (int i = 0; i < this.numberOfBalls(); i++) {
            velocityList.add(i, Velocity.fromAngleAndSpeed(300 + (30 * i), this.paddleSpeed()));
        }
        return velocityList;
    }
    @Override
    public final int paddleSpeed() { return 8; }
    @Override
    public final int paddleWidth() { return 100; }
    @Override
    public final String levelName() { return "Blue & White"; }
    @Override
    public final Sprite getBackground() { return new Level4Background(); }
    @Override
    public final List<Block> blocks() {
        List<Block> blockList = new ArrayList<>();
        Color color = new Color(13, 160, 250);
        for (int i = 10; i < 790; i += 60) {
            if (i == 370) { continue; }
            for (int j = 150; j <= 300; j += 30) {
                Block block = new Block(new Point(i, j), 60, 30, color, 1);
                blockList.add(block);
            }
        }
        return blockList;
    }
    @Override
    public final int numberOfBlocksToRemove() { return this.blocks().size() + this.getBlocksThatSplitBall().size()
            + this.getDeathBlocks().size(); }
    @Override
    public final Color getCountdownColor() {
            return Color.BLACK;
        }
    @Override
    public final List<Block> getBlocksThatSplitBall() {
        List<Block> splitBall = new ArrayList<>();
        for (int i = 10; i < 790; i += 60) {
            if (i == 370) { continue; }
            Block block = new Block(new Point(i, 120), 60, 30, Color.BLUE, 3);
            splitBall.add(block);
        }
        return splitBall;
    }

    @Override
    public final List<Block> getDeathBlocks() {
        List<Block> deathBlocks = new ArrayList<>();
        for (int i = 120; i < 330; i += 30) {
            deathBlocks.add(new Block(new Point(370, i), 60, 30, Color.BLUE, 1));
        }
        return deathBlocks;
    }
}
