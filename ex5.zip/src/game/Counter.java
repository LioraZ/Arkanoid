package game;
/**
 * Defining an Counter class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class Counter {
    /**
     * value: The counter's value.
     */
    private int value;

    /**
     * The Counter's default constructor, initializes the value to 0.
     */
    public Counter() { this.value = 0; }

    /**
     * he Counter's constructor, initializes the value to the number received.
     * @param number The number the value should be initialized to.
     */
    public Counter(final int number) { this.value = number; }

    /**
     * The method increases the value by a given number.
     * @param number The given number which the value should be increased by.
     */
    public final void increase(final int number) { this.value += number; }
    /**
     * The method increases the value by 1.
     */
    public final void increase() { this.value++; }

    /**
     * The method decreases the value by a given number.
     * @param number The given number which the value should be decreased by.
     */
    public final void decrease(final int number) { this.value -= number; }
    /**
     * The method decreases the value by 1.
     */
    public final void decrease() { this.value--; }

    /**
     * The method is an accessor to the Counter's value.
     * @return the Counter's value.
     */
    public final int getValue() { return this.value; }
}
