package game;
import annimations.Animation;
import annimations.AnimationRunner;
import annimations.CountdownAnimation;
import annimations.PauseScreen;
import collidables.Block;
import collidables.Collidable;
import collidables.GameEnvironment;
import collidables.Paddle;
import hitlisteners.BallRemover;
import hitlisteners.BlockRemover;
import hitlisteners.HitListener;
import hitlisteners.SplitBall;
import hitlisteners.DeathBlock;
import sprites.LivesIndicator;
import hitlisteners.ScoreTrackingListener;
import levels.LevelInformation;
import biuoop.DrawSurface;
import java.awt.Color;
import java.util.List;
import biuoop.KeyboardSensor;
import geometry.Point;
import geometry.Velocity;
import geometry.Rectangle;
import sprites.LevelIndicator;
import sprites.ScoreIndicator;
import sprites.Sprite;
import sprites.SpriteCollection;

/**
 * Defining a GameLevel class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class GameLevel implements HitListener, Animation {

    /**
     * sprites: A SpriteCollection to store all the game's sprites.
     */
    private SpriteCollection sprites;
    /**
     * environment: A GameEnvironment to store the game's Collidable objects.
     */
    private GameEnvironment environment;

    /**
     * blockCounter: A counter to keep track of the level's blocks.
     */
    private Counter blockCounter;
    /**
     * ballCounter: A counter to keep track of the level's balls.
     */
    private Counter ballCounter;
    /**
     * scoreCounter: A counter to keep track of the game's score.
     */
    private Counter scoreCounter;
    /**
     * livesCounter: A counter to keep track of the game's lives.
     */
    private Counter livesCounter;

    /**
     * runner: The games AnimationRunner.
     */
    private AnimationRunner runner;
    /**
     * running: A boolean variable to determine the running of the runner.
     */
    private boolean running;

    /**
     * keyboard: The game's keyboard sensor.
     */
    private KeyboardSensor keyboard;
    /**
     * levelInformation: The level information.
     */
    private LevelInformation levelInformation;

    /**
     * The GameLevel's constructor.
     * Creating a SpriteCollection and a GameEnvironment to store the sprites and collidables, and initializing the
     * counters
     * @param levelInfo The level information.
     * @param keyboardSensor The game's keyboard sensor.
     * @param ar The games AnimationRunner.
     * @param lives A counter to keep track of the game's lives.
     * @param score A counter to keep track of the game's score.
     */
    public GameLevel(final LevelInformation levelInfo, final KeyboardSensor keyboardSensor,
                     final AnimationRunner ar, final Counter lives, final Counter score) {
        this.levelInformation = levelInfo;
        this.sprites = new SpriteCollection();
        this.environment = new GameEnvironment();
        this.blockCounter = new Counter();
        this.ballCounter = new Counter();
        this.scoreCounter = score;
        this.livesCounter = lives;
        this.runner = ar;
        this.running = true;
        this.keyboard = keyboardSensor;
    }

    /**
     * The method adds a Collidable to the game's GameEnvironment(collidables list).
     * @param c The Collidable being added to the GameEnvironment.
     */
    public final void addCollidable(final Collidable c) { this.environment.addCollidable(c); }
    /**
     * The method adds a Sprite to the game's SpriteCollection(sprites list).
     * @param s The Sprite being added to the SpriteCollection.
     */
    public final void addSprite(final Sprite s) { this.sprites.addSprite(s); }

    /**
     * The method removes the Collidable to the gameLevel's GameEnvironment(collidables list).
     * @param c The Collidable being removed from the GameEnvironment.
     */
    public final void removeCollidable(final Collidable c) { this.environment.removeCollidable(c); }

    /**
     * The method removes the Sprite to the gameLevel's SpriteCollection(sprites list).
     * @param s The Sprite being removed from the SpriteCollection.
     */
    public final void removeSprite(final Sprite s) { this.sprites.removeSprite(s); }

    /**
     * The method initializes a new gameLevel: it creates the Blocks and associates them with the level.
     */
    public final void initialize() {
        BallRemover ballRemover = new BallRemover(this, this.ballCounter);
        BlockRemover blockRemover = new BlockRemover(this, this.blockCounter);

        sprites.addSprite(this.levelInformation.getBackground());
        this.addScreenBorders();
        this.addDeathBlock(ballRemover);

        ScoreTrackingListener scoreTracker = new ScoreTrackingListener(this.scoreCounter);
        ScoreIndicator scoreIndicator = new ScoreIndicator(this.scoreCounter);
        scoreIndicator.addToGame(this);
        LevelIndicator levelIndicator = new LevelIndicator(this.levelInformation.levelName());
        levelIndicator.addToGame(this);
        LivesIndicator lives = new LivesIndicator(this.livesCounter);
        lives.addToGame(this);
        this.addBlocks(blockRemover, scoreTracker);

        //Initializing special blocks
        DeathBlock deathB = new DeathBlock(this, ballCounter, 1);
        this.addLevelDeathBlocks(deathB, blockRemover);
        SplitBall splitBall = new SplitBall(this, this.blockCounter, this.ballCounter);
        this.addSplitBallBlocks(splitBall);
    }

    /**
     * The method initializes the border death block.
     * @param ballRemover The border death block's HitListener.
     */
    private void addDeathBlock(final BallRemover ballRemover) {
        Block deathBlock = new Block(new Point(-100, 615), 1000, 10, Color.black, 0);
        deathBlock.addToGame(this);
        deathBlock.addHitListener(ballRemover);
    }

    /**
     * The method initializes the special game death blocks the is received from the level information.
     * @param deathB The deathBlock HitListener.
     * @param blockRemover The blockRemover HitListener.
     */
    private void addLevelDeathBlocks(final DeathBlock deathB, final BlockRemover blockRemover) {
        for (Block db: this.levelInformation.getDeathBlocks()) {
            db.addToGame(this);
            db.addHitListener(deathB);
            db.addHitListener(blockRemover);
        }
    }

    /**
     * The method will add the game blocks that were received from the level information.
     * @param blockRemover The blockRemover HitListener.
     * @param scoreTracker The scoreTrackingListener HitListener.
     */
    private void addBlocks(final BlockRemover blockRemover, final ScoreTrackingListener scoreTracker) {
        for (Block block: this.levelInformation.blocks()) {
            block.addToGame(this);
            block.addHitListener(blockRemover);
            block.addHitListener(scoreTracker);
        }
        this.blockCounter.increase(this.levelInformation.numberOfBlocksToRemove());
    }

    /**
     * The method initializes the special game split ball blocks that were received from the level information.
     * @param splitBall The SplitBall HitListener.
     */
    private void addSplitBallBlocks(final SplitBall splitBall) {
        for (Block splitBallBlock: this.levelInformation.getBlocksThatSplitBall()) {
            splitBallBlock.addToGame(this);
            splitBallBlock.addHitListener(splitBall);
        }
    }

    /**
     * The method creates screen borders.
     */
    public final void addScreenBorders() {
        Block b1 = new Block(new Point(0, 10), 10, 600, Color.BLACK, 0);
        Block b2 = new Block(new Point(0, 0), 800, 32, Color.BLACK, 0);
        Block b3 = new Block(new Point(790, 0), 10, 600, Color.BLACK, 0);
        Block separationLine = new Block(new Point(0, 20), 800, 2, Color.WHITE, 0);
        b1.addToGame(this);
        b2.addToGame(this);
        b3.addToGame(this);
        separationLine.addToGame(this);
    }
    @Override
    public final void hitEvent(final Block beingHit, final Ball hitter) { }  //beingHit.removeFromGame(this); }
    @Override
    public final boolean shouldStop() { return !this.running; }
    @Override
    public final void doOneFrame(final DrawSurface d) {
        if (this.keyboard.isPressed("p")) { this.runner.run(new PauseScreen(this.keyboard)); }
        this.sprites.notifyAllTimePassed();
        if (this.blockCounter.getValue() == 0) { this.running = false; }
        if (this.ballCounter.getValue() == 0) {
            this.livesCounter.decrease();
            this.running = false;
        }
        this.sprites.drawAllOn(d);
    }
    /**
     * The method runs the level by calling the animationRunner.
     */
    public final void playOneTurn() {
        Paddle paddle = this.createBallsOnTopOfPaddle();
        this.running = true;
        this.runner.run(this);
        paddle.removeFromGame(this);

    }

    /**
     * Thr method initializes the level's balls and paddle, and returns the paddle.
     * @return The paddle.
     */
    private Paddle createBallsOnTopOfPaddle() {
        Point paddleStartPoint = new Point(400 - this.levelInformation.paddleWidth() / 2, 578);
        Paddle paddle = new Paddle(new Rectangle(paddleStartPoint, this.levelInformation.paddleWidth(), 20),
                Color.BLACK, this.levelInformation.paddleSpeed(), this.keyboard);
        paddle.addToGame(this);
        int numBalls = this.levelInformation.numberOfBalls();
        List<Velocity> velocityList = this.levelInformation.initialBallVelocities();
        for (int i = 1; i <= numBalls; i++) {
            Velocity velocity = velocityList.get(i - 1);
            velocity.verticalChange();
            Point point = velocity.applyToPoint(new Point(400, 578));
            Ball ball = new Ball(point, 5, Color.BLACK, this.environment);
            ball.setVelocity(velocity);
            ball.addToGame(this);
        }
        this.ballCounter.increase(numBalls);
        this.runner.run(new CountdownAnimation(2, 3, this.sprites,
                this.levelInformation.getCountdownColor()));
        return paddle;
        }

    /**
     * The method returns true if there are any blocks left on the screen and else false.
     * @return True if there are any blocks left on the screen and else false.
     */
    public final boolean blocksAreLeft() {
       return this.blockCounter.getValue() != 0;
    }
}


