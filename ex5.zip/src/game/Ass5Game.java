package game;
import annimations.AnimationRunner;
import levels.Level1;
import levels.Level2;
import levels.Level3;
import levels.Level4;
import levels.LevelInformation;
import biuoop.KeyboardSensor;
import java.util.ArrayList;
import java.util.List;

/**
 * Defining an Ass3Game class to run assignment 3.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class Ass5Game {
    /**
     * The main creates an object of type game, and calls a methods to initialize and run the game.
     * @param args The main's arguments.
     */
    public static void main(final String[] args) {
        List<LevelInformation> levelInfo = new ArrayList<>();
        LevelInformation[] levelInfoArray = new LevelInformation[4];
        levelInfoArray[0] = new Level1();
        levelInfoArray[1] = new Level2();
        levelInfoArray[2] = new Level3();
        levelInfoArray[3] = new Level4();
        if (args.length == 0) {
            for (int i = 0; i < levelInfoArray.length; i++) { levelInfo.add(i, levelInfoArray[i]); }
        } else {
            for (String level: args) {
                try {
                    int levelNumber = Integer.parseInt(level);
                    if (levelNumber > levelInfoArray.length) {
                        System.out.println("Level does not exist!");
                        continue;
                    }
                    levelInfo.add(levelInfoArray[levelNumber - 1]);
                } catch (Exception e) {
                    System.out.println("Level does not exist!");
                    continue;
                }
            }
        }
        AnimationRunner animationRunner = new AnimationRunner();
        KeyboardSensor keyboardSensor = animationRunner.getSurface().getKeyboardSensor();
        GameFlow gameFlow = new GameFlow(animationRunner, keyboardSensor);
        gameFlow.runLevels(levelInfo);
        animationRunner.getSurface().close();
    }
}
