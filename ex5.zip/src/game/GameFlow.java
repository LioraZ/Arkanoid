package game;
import annimations.AnimationRunner;
import annimations.LoseScreen;
import annimations.WinScreen;
import levels.LevelInformation;
import biuoop.KeyboardSensor;
import java.util.List;

/**
 * Defining a GameFlow class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class GameFlow {
    /**
     * animationRunner: The gameFlow's AnimationRunner.
     */
    private AnimationRunner animationRunner;
    /**
     * keyboardSensor: The gameFlow's KeyboardSensor.
     */
    private KeyboardSensor keyboardSensor;
    /**
     * lives: A counter to keep track of the lives.
     */
    private Counter lives;
    /**
     * score: A counter to keep track of the lives.
     */
    private Counter score;

    /**
     * The gameFlow's constructor.
     * The gameFlow is in charge of running the levels and ending the game.
     * @param ar The gameFlow's AnimationRunner.
     * @param ks The gameFlow's KeyboardSensor.
     */
    public GameFlow(final AnimationRunner ar, final KeyboardSensor ks) {
        this.animationRunner = ar;
        this.keyboardSensor = ks;
        this.lives = new Counter(7);
        this.score = new Counter();
    }

    /**
     * The method runs the levels in order while keeping tracks of the lives and score, and ends the game.
     * @param levels A list of the game levels.
     */
    public final void runLevels(final List<LevelInformation> levels) {
        for (LevelInformation levelInfo : levels) {
            GameLevel level = new GameLevel(levelInfo, this.keyboardSensor, this.animationRunner, this.lives,
                    this.score);
            level.initialize();
            while (this.lives.getValue() != 0 && level.blocksAreLeft()) { level.playOneTurn(); }
            if (this.lives.getValue() == 0) {
                this.animationRunner.run(new LoseScreen(this.score, this.keyboardSensor));
                return;
            }
            this.score.increase(100);
        }
        if (levels.size() != 0) { this.animationRunner.run(new WinScreen(this.score, this.keyboardSensor)); }
    }
}
