package game;
import sprites.Sprite;
import collidables.GameEnvironment;
import collidables.CollisionInfo;
import java.awt.Color;
import biuoop.DrawSurface;
import java.util.Random;
import geometry.Velocity;
import geometry.Point;
import geometry.Line;
/**
 * Defining a Ball class.
 *
 * I.D. 323742775
 * Email: liorazr@gmail.com
 * @author  Liora Zaidner
 */
public class Ball implements Sprite {

    /**
     * radius: The size of the ball's radius.
     */
    private int radius;
    /**
     * center: The ball's center Point.
     */
    private Point center;
    /**
     * color: The ball's color.
     */
    private Color color;
    /**
     * velocity: The ball's movement velocity.
     */
    private Velocity velocity;
    /**
     * gameEnvironment: The ball's game Environment(list of collidables).
     */
    private GameEnvironment gameEnvironment;

    /**
     * The Ball's constructor.
     * In addition, the constructor sets the ball's velocity and frame to be their default.
     *
     * @param centerPoint The center Point of the ball.
     * @param r           The size of the Ball's radius.
     * @param colorBall   The Ball's color.
     * @param environment The Ball's GameEnvironment(list of collidables).
     */
    public Ball(final Point centerPoint, final int r, final Color colorBall, final GameEnvironment environment) {
        this.center = centerPoint;
        this.radius = r;
        this.color = colorBall;
        this.velocity = new Velocity();
        this.gameEnvironment = environment;
    }

    /**
     * The Ball's constructor.
     * In addition, the constructor sets the ball's velocity and frame to be their default.
     *
     * @param x           The Ball's center Point x value.
     * @param y           The Ball's center Point y value.
     * @param r           The size of the Ball's radius.
     * @param colorBall   The Ball's color.
     * @param environment The Ball's GameEnvironment(list of collidables).
     */
    public Ball(final int x, final int y, final int r, final Color colorBall, final GameEnvironment environment) {
        this(new Point((double) x, (double) y), r, colorBall, environment);
    }

    /**
     * The Ball's copy constructor.
     * @param other The ball that is copied from.
     */
    public Ball(final Ball other) {
        this.center = new Point(other.center.getX(), other.center.getY());
        this.radius = other.radius;
        this.color = other.color;
        this.gameEnvironment = other.gameEnvironment;
    }

    /**
     * The Ball's constructor.
     * In addition, the constructor sets the ball's velocity and frame to be their default, and generates a random
     * color for the ball.
     *
     * @param x           The Ball's center Point x value.
     * @param y           The Ball's center Point y value.
     * @param r           The size of the Ball's radius.
     * @param environment The Ball's GameEnvironment(list of collidables).
     */
    public Ball(final int x, final int y, final int r, final GameEnvironment environment) {
        this(x, y, r, Color.WHITE, environment);
        this.generateRandomColor();
    }

    /**
     * The method is an accessor to the Ball's radius.
     *
     * @return The radius of the Ball.
     */
    public final int getSize() {
        return this.radius;
    }

    /**
     * The method is an accessor to the Ball's center.
     * @return The ball's center.
     */
    public final Point getCenter() { return this.center; }

    /**
     * The method updates the Ball's center (used for animation).
     * @param pointCenter The Ball's new Center.
     */
    public final void setCenter(final Point pointCenter) {
        this.center = pointCenter;
    }

    /**
     * The method generates a random color for the ball.
     */
    private void generateRandomColor() {
        Random rand = new Random();
        float r = rand.nextFloat();
        float g = rand.nextFloat();
        float b = rand.nextFloat();
        this.color = new Color(r, g, b);
    }

    /**
     * The method draws the Ball on a given Drawsurface.
     *
     * @param surface The given drawSurface which the Ball will be drawn on.
     */
    @Override
    public final void drawOn(final DrawSurface surface) {
        surface.setColor(this.color);
        surface.fillCircle((int) this.center.getX(), (int) this.center.getY(), this.radius);
    }

    /**
     * The method sets the Ball's velocity.
     *
     * @param v The Ball's new velocity.
     */
    public final void setVelocity(final Velocity v) {
        this.velocity = v;
    }

    /**
     * The method accesses the Ball's velocity and returns it.
     *
     * @return The Ball's velocity.
     */
    public final Velocity getVelocity() {
        return this.velocity;
    }

    /**
     * The method moves the Ball's location on a surface according to its velocity, taking into account collisions
     * that can occur with other objects on the screen.
     */
    @Override
    public final void timePassed() {
        Line trajectory = new Line(this.center, this.velocity.applyToPoint(this.center));
        CollisionInfo collisionInfo = this.gameEnvironment.getClosestCollision(trajectory);
        if (collisionInfo == null) {
            trajectory.end().round();
            this.center = trajectory.end();
        } else {
            if (collisionInfo.getOtherCollisionsListSize() > 0) { collisionInfo.hitsOtherCollidables(this.velocity); }
            Point collisionPoint = collisionInfo.collisionPoint();
            this.velocity = collisionInfo.collisionObject().hit(this, collisionPoint, this.velocity);
            double dx = 0.0001, dy = 0.0001;
            if (this.velocity.getDx() > 0) { dx = -dx; }
            if (this.velocity.getDy() > 0) { dy = -dy; }
            this.center = new Point(collisionPoint.getX() - dx, collisionPoint.getY() - dy);
        }
    }

    /**
     * The method adds the ball to the game.
     * @param game The game object which is passed, so the Ball can add itself to the relevant members in game.
     */
    public final void addToGame(final GameLevel game) {
        game.addSprite(this);
    }

    /**
     * The method removes the Ball from the game.
     * @param game The game object which is passed, so the Ball can remove itself from the relevant members in game.
     */
    public final void removeFromGame(final GameLevel game) { game.removeSprite(this); }
}
